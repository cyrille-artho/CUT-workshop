#!/bin/sh

javac *.java
